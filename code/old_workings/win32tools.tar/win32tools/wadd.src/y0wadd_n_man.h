#ifndef Y0WADD_N_MAN_HHHH
#define Y0WADD_N_MAN_HHHH
#include  <stdio.h>
#include  <string.h>

#define   DEBUG   0
/* #define   MAXSIZE   300000 */
#define   MAXSIZE   30000000
#define   NAMLEN    256
#define   TEMPNAME  "wadd.tmp"

#include <y0wadd_prot.h>

#endif
