#ifndef Y1MKUTIL_MAN_HHH
#define Y1MKUTIL_MAN_HHH

#include <stdio.h>


#endif
