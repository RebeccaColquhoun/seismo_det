#include <stdlib.h>
#include <y1wch_prot.h>
void ctrlc(int iii) {
    exit(1);
}
