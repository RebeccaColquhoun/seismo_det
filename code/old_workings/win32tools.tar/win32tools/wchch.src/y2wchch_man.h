#ifndef Y2WCHCH_MAN_HHH
#define Y2WCHCH_MAN_HHH

#include  <stdio.h>
#include  <signal.h>

#define   DEBUG   0
#define   DEBUG1  0

unsigned char *buf, *outbuf;
int giNch;
unsigned int ch_table0[65536];
unsigned int ch_table1[65536];

#endif
