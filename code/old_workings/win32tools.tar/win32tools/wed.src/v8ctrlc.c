#include <stdlib.h>
void ctrlc(int iii) {
    abort();
}
