#ifndef V8BITOPER_EXT_HHHHH
#define V8BITOPER_EXT_HHHHH

#define _BITOPER_C_

#include <v8winlib.h>

extern unsigned int swaptest;
#endif
